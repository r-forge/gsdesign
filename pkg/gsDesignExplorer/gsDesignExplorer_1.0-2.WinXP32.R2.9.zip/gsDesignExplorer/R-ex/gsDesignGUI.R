### Name: gsDesignGUI
### Title: Graphical user interface functionality for gsDesign
### Aliases: gsDesignGUI
### Keywords: interface

### ** Examples

gsDesignGUI(gsDesignGUI:::fauxDesignList)



